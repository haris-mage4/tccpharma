<?php
/**
 * Copyright © 2011-2017
 * 
 * See COPYING.txt for license details.
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Vishwas_Hideprice',
    __DIR__
);
