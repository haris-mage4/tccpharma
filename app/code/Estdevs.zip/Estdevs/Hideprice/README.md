# Hide Price Extension For Magento 2

Welcome to Hide Price Extension on Magento 2.0 Installation! We're glad that you are interested in my extension. 

## Description

Hide Price is the most powerful extension for hiding the product price from non-logedIn users. This extension encourages users to register on the website.you can hide add to cart button if you want. To See the product price user required to register and login. Admin can configure the section from admin panel. admin can hide the price as well as the add to cart button. admin simply choose the hide price yes to hide the price. when price hide it will say "please login to view price". 

Admin Configuration

Hide Price - admin can set config to hide product price from front end.

Hide Add To Cart - admin can set config to hide product "add to cart" from front end.

Hide Wishlist and Compare - admin can set config to hide product "add to wishlist" and "add to compare" button from front end product listing and detail page.

Features:

» Hide the price for an individual product

» Hide the "add to cart" button for an individual product

» Enable and Disable the Module from Admin directly

» Free extension updates

» Expert support for installation and configuration 
