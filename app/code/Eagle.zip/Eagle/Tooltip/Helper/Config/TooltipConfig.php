<?php
/**
 * Copyright © Eagle All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eagle\Tooltip\Helper\Config;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class TooltipConfig extends AbstractHelper
{
    protected const REGULAR_PRICE_TOOLTIP_TEXT = 'tooltip/general/regular_price_tooltip';
    protected const SPECIAL_PRICE_TOOLTIP_TEXT = 'tooltip/general/special_price_tooltip';

    /**
     * @return mixed
     */
    public function getRegularPriceText(): mixed
    {
        return $this->scopeConfig->getValue(self::REGULAR_PRICE_TOOLTIP_TEXT, ScopeInterface::SCOPE_STORE);
    }
    /**
     * @return mixed
     */
    public function getSpecialPriceText(): mixed
    {
        return $this->scopeConfig->getValue(self::SPECIAL_PRICE_TOOLTIP_TEXT, ScopeInterface::SCOPE_STORE);
    }
}
