<?php
/**
 * Copyright © Eagle All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eagle\Tooltip\Block\Tooltip\Block;

use Eagle\Tooltip\Helper\Config\TooltipConfig;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class Price extends Template
{

    /**
     * Constructor
     *
     * @param Context $context
     * @param TooltipConfig $tooltipConfig
     * @param array $data
     */
    public function __construct(
        Context $context,
        TooltipConfig $tooltipConfig,
        array $data = []
    ) {
        $this->tooltipConfig = $tooltipConfig;
        parent::__construct($context, $data);
    }

    /**
     * @return string|null
     */
    public function getRegularTooltipText(): ?string
    {
        return $this->tooltipConfig->getRegularPriceText();
    }

}

