<?php

namespace Amasty\RequestQuote\ViewModel;
use Amasty\RequestQuote\Api\QuoteRepositoryInterface;
use Amasty\RequestQuote\Model\Source\Status;
class Data implements \Magento\Framework\View\Element\Block\ArgumentInterface
{

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $customerFactory;

    /**
     * @param \Magento\Catalog\Model\CustomerFactory     $customerFactory
     */
    public function __construct(
        QuoteRepositoryInterface $repository,
        Status $status
    ) {
        $this->repository=$repository;
        $this->status=$status;
    }

    public function getAdminRemark($quoteId) {
        try{
                $repo=$this->repository->get($quoteId);
                $data=json_decode($repo['remarks'], true);
                $status=$this->status->getStatusLabel($repo->getStatus());
                $data['status']=$status;
                return $data;
        }catch(\Exception $e){
            return null;
        }   
    }

      public function getRefererUrl()
    {
        return $this->request->getServer('HTTP_REFERER');
    }
}