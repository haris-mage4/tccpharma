<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2023 Amasty (https://www.amasty.com)
 * @package Request a Quote Base for Magento 2
 */

namespace Amasty\RequestQuote\Block\Cart\Item\Renderer;

class Actions extends \Magento\Checkout\Block\Cart\Item\Renderer\Actions
{
}
